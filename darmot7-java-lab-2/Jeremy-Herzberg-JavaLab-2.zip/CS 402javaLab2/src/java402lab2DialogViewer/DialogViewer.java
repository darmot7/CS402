package java402lab2DialogViewer;

import javax.swing.JOptionPane;

public class DialogViewer {

	public DialogViewer() {
		JOptionPane filePrompt = new JOptionPane();
		filePrompt.createDialog("Don't be bad");
		
	}
}
